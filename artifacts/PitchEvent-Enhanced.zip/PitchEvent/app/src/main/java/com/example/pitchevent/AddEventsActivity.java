// Fixes added for milestone 2 by J. Palacio tested 9/20 for final submission
package com.example.pitchevent;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddEventsActivity extends AppCompatActivity {

    private EditText editEventName;
    private EditText editEventDate;
    private EditText editEventTime;
    private EditText editEventLocation;
    private EditText editEventNotes;

    private Button buttonSaveEvent;
    private DatabaseHelper databaseHelper;

    private int eventId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        editEventName = findViewById(R.id.editEventName);
        editEventDate = findViewById(R.id.editEventDate);
        editEventTime = findViewById(R.id.editEventTime);
        editEventLocation = findViewById(R.id.editEventLocation);
        editEventNotes = findViewById(R.id.editEventNotes);
        buttonSaveEvent = findViewById(R.id.buttonSaveEvent);

        databaseHelper = new DatabaseHelper(this);

        // Checking whether the screen was opened to edit an existing event.
        eventId = getIntent().getIntExtra("eventId", -1);

        if (eventId != -1) {

            // Load each stored value back into its corrrect field.
            editEventName.setText(getIntent().getStringExtra("eventName"));
            editEventDate.setText(getIntent().getStringExtra("eventDate"));
            editEventTime.setText(getIntent().getStringExtra("eventTime"));
            editEventLocation.setText(getIntent().getStringExtra("eventLocation"));
            editEventNotes.setText(getIntent().getStringExtra("eventNotes"));

            buttonSaveEvent.setText("Update Event");
        }

        buttonSaveEvent.setOnClickListener(v -> saveEvent());
    }

    private void saveEvent() {

        String name = editEventName.getText().toString().trim();
        String date = editEventDate.getText().toString().trim();
        String time = editEventTime.getText().toString().trim();
        String location = editEventLocation.getText().toString().trim();
        String notes = editEventNotes.getText().toString().trim();

        // Validates event information.
        if (name.isEmpty()) {
            editEventName.setError("Event name is required.");
            editEventName.requestFocus();
            return;
        }

        if (date.isEmpty()) {
            editEventDate.setError("Event date is required.");
            editEventDate.requestFocus();
            return;
        }

        boolean success;

        if (eventId == -1) {

            // Saves each event value separately.
            // New events begin with Upcoming status for save state.
            success = databaseHelper.addEvent(
                    name,
                    date,
                    time,
                    location,
                    notes
            );

        } else {

            // Updates event information without changing its status in UI.
            success = databaseHelper.updateEvent(
                    eventId,
                    name,
                    date,
                    time,
                    location,
                    notes
            );
        }

        if (success) {

            String message;

            if (eventId == -1) {
                message = "Event added.";
            } else {
                message = "Event updated.";
            }

            Toast.makeText(
                    this,
                    message,
                    Toast.LENGTH_SHORT
            ).show();

            finish();

        } else {

            Toast.makeText(
                    this,
                    "Event could not be saved.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}