package com.example.pitchevent;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

// This class creates and manages the app database.
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "PitchEvent.db";

    // Version 3 separates event time, location, and notes.
    private static final int DATABASE_VERSION = 3;

    private static final String TABLE_USERS = "users";
    private static final String USER_ID = "id";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";

    private static final String TABLE_EVENTS = "events";
    private static final String EVENT_ID = "id";
    private static final String EVENT_NAME = "eventName";
    private static final String EVENT_DATE = "eventDate";

    // Added separate fields for better event data organization.
    private static final String EVENT_TIME = "eventTime";
    private static final String EVENT_LOCATION = "eventLocation";
    private static final String EVENT_NOTES = "eventNotes";

    private static final String EVENT_STATUS = "eventStatus";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creates the database tables when the app database is first made.
    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USERNAME + " TEXT UNIQUE, " +
                PASSWORD + " TEXT)";

        String createEventsTable = "CREATE TABLE " + TABLE_EVENTS + " (" +
                EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EVENT_NAME + " TEXT, " +
                EVENT_DATE + " TEXT, " +
                EVENT_TIME + " TEXT, " +
                EVENT_LOCATION + " TEXT, " +
                EVENT_NOTES + " TEXT, " +
                EVENT_STATUS + " TEXT DEFAULT 'Upcoming')";

        db.execSQL(createUsersTable);
        db.execSQL(createEventsTable);
    }

    // Updates older db versions without deleting existing data on local.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Ver 2 added the event lifecycle status.
        if (oldVersion < 2) {
            db.execSQL(
                    "ALTER TABLE " + TABLE_EVENTS +
                            " ADD COLUMN " + EVENT_STATUS +
                            " TEXT DEFAULT 'Upcoming'"
            );
        }

        // Ver 3 separates time, location, and notes
        // instead of storing combined strings as one long line.
        if (oldVersion < 3) {
            db.execSQL(
                    "ALTER TABLE " + TABLE_EVENTS +
                            " ADD COLUMN " + EVENT_TIME + " TEXT"
            );

            db.execSQL(
                    "ALTER TABLE " + TABLE_EVENTS +
                            " ADD COLUMN " + EVENT_LOCATION + " TEXT"
            );

            db.execSQL(
                    "ALTER TABLE " + TABLE_EVENTS +
                            " ADD COLUMN " + EVENT_NOTES + " TEXT"
            );
        }
    }

    // Adds a new user account.
    // The password is hashed instead of being stored as plain text see line 215.
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(PASSWORD, hashPassword(password));

        long result = db.insert(TABLE_USERS, null, values);

        return result != -1;
    }

    // Checks the username and hashed password against a saved account. Local only
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String hashedPassword = hashPassword(password);

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS +
                        " WHERE " + USERNAME + "=? AND " + PASSWORD + "=?",
                new String[]{username, hashedPassword}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();

        return exists;
    }

    // Adds a new event. Values solo.
    public boolean addEvent(String name, String date, String time,
                            String location, String notes) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(EVENT_NAME, name);
        values.put(EVENT_DATE, date);
        values.put(EVENT_TIME, time);
        values.put(EVENT_LOCATION, location);
        values.put(EVENT_NOTES, notes);

        // Every new event begins in the Upcoming stage.
        values.put(EVENT_STATUS, "Upcoming");

        long result = db.insert(TABLE_EVENTS, null, values);

        return result != -1;
    }

    // Gets all events.
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_EVENTS,
                null
        );
    }

    // Updates all editable information for an existing event.
    public boolean updateEvent(int id, String name, String date,
                               String time, String location, String notes) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(EVENT_NAME, name);
        values.put(EVENT_DATE, date);
        values.put(EVENT_TIME, time);
        values.put(EVENT_LOCATION, location);
        values.put(EVENT_NOTES, notes);

        int result = db.update(
                TABLE_EVENTS,
                values,
                EVENT_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // Updates only the lifecycle status of an event.
    public boolean updateEventStatus(int id, String status) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(EVENT_STATUS, status);

        int result = db.update(
                TABLE_EVENTS,
                values,
                EVENT_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // Deletes an event.
    public boolean deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                TABLE_EVENTS,
                EVENT_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // Simple Hashes no storage for SQlite
    private String hashPassword(String password) {

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            byte[] hash = digest.digest(
                    password.getBytes(StandardCharsets.UTF_8)
            );

            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);

                if (hex.length() == 1) {
                    hexString.append('0');
                }

                hexString.append(hex);
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(
                    "Unable to hash password.",
                    e
            );
        }
    }
}