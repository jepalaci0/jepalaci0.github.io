package com.example.pitchevent;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private Context context;
    private ArrayList<Event> eventList;
    private DatabaseHelper databaseHelper;

    public EventAdapter(Context context, ArrayList<Event> eventList,
                        DatabaseHelper databaseHelper) {
        this.context = context;
        this.eventList = eventList;
        this.databaseHelper = databaseHelper;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_event, parent, false);

        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {

        Event event = eventList.get(position);

        holder.textEventName.setText(event.getName());

        // Date and time are stored separately but combined for display.
        String dateTime = event.getDate();

        if (event.getTime() != null && !event.getTime().isEmpty()) {
            dateTime += " at " + event.getTime();
        }

        holder.textEventDateTime.setText(dateTime);

        // Location and notes are also stored separately
        // and combined only when displayed on the event card.
        String eventInfo = "";

        if (event.getLocation() != null && !event.getLocation().isEmpty()) {
            eventInfo = event.getLocation();
        }

        if (event.getNotes() != null && !event.getNotes().isEmpty()) {

            if (!eventInfo.isEmpty()) {
                eventInfo += " - ";
            }

            eventInfo += event.getNotes();
        }

        holder.textEventInfo.setText(eventInfo);

        // Displays the current event lifecycle status.
        holder.textEventStatus.setText(
                "Status: " + event.getStatus()
        );

        // Opens the event screen in edit mode.
        // Each event value is now sent separately.
        holder.itemView.setOnClickListener(v -> {

            Intent intent = new Intent(
                    context,
                    AddEventsActivity.class
            );

            intent.putExtra("eventId", event.getId());
            intent.putExtra("eventName", event.getName());
            intent.putExtra("eventDate", event.getDate());
            intent.putExtra("eventTime", event.getTime());
            intent.putExtra("eventLocation", event.getLocation());
            intent.putExtra("eventNotes", event.getNotes());

            context.startActivity(intent);
        });

        // Moves the event to next stage.
        holder.buttonNextStatus.setOnClickListener(v -> {

            int currentPosition =
                    holder.getBindingAdapterPosition();

            if (currentPosition != RecyclerView.NO_POSITION) {

                Event currentEvent =
                        eventList.get(currentPosition);

                String nextStatus =
                        getNextStatus(currentEvent.getStatus());

                boolean updated =
                        databaseHelper.updateEventStatus(
                                currentEvent.getId(),
                                nextStatus
                        );

                if (updated) {
                    currentEvent.setStatus(nextStatus);
                    notifyItemChanged(currentPosition);
                }
            }
        });

        // Removes the event only if the database deletion succeeds.
        holder.buttonDeleteEvent.setOnClickListener(v -> {

            int currentPosition =
                    holder.getBindingAdapterPosition();

            if (currentPosition != RecyclerView.NO_POSITION) {

                Event currentEvent =
                        eventList.get(currentPosition);

                boolean deleted =
                        databaseHelper.deleteEvent(
                                currentEvent.getId()
                        );

                if (deleted) {
                    eventList.remove(currentPosition);
                    notifyItemRemoved(currentPosition);
                }
            }
        });
    }

    //  sees next stage in the event lifecycle.
    private String getNextStatus(String currentStatus) {

        if (currentStatus == null) {
            return "Upcoming";
        }

        switch (currentStatus) {

            case "Upcoming":
                return "Reminder Due";

            case "Reminder Due":
                return "Completed";

            case "Completed":
                return "Archived";

            case "Archived":
            default:
                return "Archived";
        }
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    public static class EventViewHolder
            extends RecyclerView.ViewHolder {

        TextView textEventName;
        TextView textEventDateTime;
        TextView textEventInfo;
        TextView textEventStatus;

        Button buttonDeleteEvent;
        Button buttonNextStatus;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);

            textEventName =
                    itemView.findViewById(R.id.textEventName);

            textEventDateTime =
                    itemView.findViewById(R.id.textEventDateTime);

            textEventInfo =
                    itemView.findViewById(R.id.textEventInfo);

            textEventStatus =
                    itemView.findViewById(R.id.textEventStatus);

            buttonDeleteEvent =
                    itemView.findViewById(R.id.buttonDeleteEvent);

            buttonNextStatus =
                    itemView.findViewById(R.id.buttonNextStatus);
        }
    }
}