package com.example.pitchevent;

public class Event {

    private int id;
    private String name;
    private String date;

    // Added separate fields so event data is not stored
    // as combined date/time and location/notes strings as descirbed in code review.
    private String time;
    private String location;
    private String notes;

    // Tracks the current stage of the event lifecycle.
    private String status;

    // Updated constructor
    public Event(int id, String name, String date, String time,
                 String location, String notes, String status) {

        this.id = id;
        this.name = name;
        this.date = date;
        this.time = time;
        this.location = location;
        this.notes = notes;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    // Added getters for the separated event information.
    public String getTime() {
        return time;
    }

    public String getLocation() {
        return location;
    }

    public String getNotes() {
        return notes;
    }

    public String getStatus() {
        return status;
    }

    // Allows the event lifecycle to be updated for new items
    public void setStatus(String status) {
        this.status = status;
    }
}