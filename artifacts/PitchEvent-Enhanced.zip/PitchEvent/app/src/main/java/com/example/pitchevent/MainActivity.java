// Fixes added for milestone 2 by J. Palacio tested 9/20 for final submission
package com.example.pitchevent;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editUsername, editPassword;
    Button buttonLogin, buttonCreateAccount;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        databaseHelper = new DatabaseHelper(this);

        // Checks the entered username and password against the database - local
        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean validUser = databaseHelper.checkUser(username, password);

            if (validUser) {
                Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, SmsActivity.class));            } else {
                Toast.makeText(this, "Invalid login. Create an account first.", Toast.LENGTH_SHORT).show();
            }
        });

        // Creates a new account and saves it to the database - not user specific atm. Needs update to attach each user to its device.
        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean inserted = databaseHelper.insertUser(username, password);

            if (inserted) {
                Toast.makeText(this, "Account created. You can now log in.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Account already exists.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}