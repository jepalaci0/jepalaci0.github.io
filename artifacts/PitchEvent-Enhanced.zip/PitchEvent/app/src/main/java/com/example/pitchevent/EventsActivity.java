package com.example.pitchevent;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class EventsActivity extends AppCompatActivity {

    private RecyclerView recyclerEvents;
    private Button buttonAddEvent;
    private DatabaseHelper databaseHelper;
    private ArrayList<Event> eventList;
    private EventAdapter eventAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        recyclerEvents = findViewById(R.id.recyclerEvents);
        buttonAddEvent = findViewById(R.id.buttonAddEvent);

        databaseHelper = new DatabaseHelper(this);
        eventList = new ArrayList<>();

        recyclerEvents.setLayoutManager(new LinearLayoutManager(this));

        buttonAddEvent.setOnClickListener(v -> {
            Intent intent = new Intent(
                    EventsActivity.this,
                    AddEventsActivity.class
            );
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Reloads events whenever the user returns to this screen.
        loadEvents();
    }

    // Loads event data from SQLite into Event objects.
    private void loadEvents() {

        eventList.clear();

        Cursor cursor = databaseHelper.getAllEvents();

        if (cursor.moveToFirst()) {

            do {
                // Uses column names instead of fixed positions
                // so database changes are easier to maintain.
                int id = cursor.getInt(
                        cursor.getColumnIndexOrThrow("id")
                );

                String name = cursor.getString(
                        cursor.getColumnIndexOrThrow("eventName")
                );

                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow("eventDate")
                );

                String time = cursor.getString(
                        cursor.getColumnIndexOrThrow("eventTime")
                );

                String location = cursor.getString(
                        cursor.getColumnIndexOrThrow("eventLocation")
                );

                String notes = cursor.getString(
                        cursor.getColumnIndexOrThrow("eventNotes")
                );

                String status = cursor.getString(
                        cursor.getColumnIndexOrThrow("eventStatus")
                );

                // Creates an Event.
                eventList.add(
                        new Event(
                                id,
                                name,
                                date,
                                time,
                                location,
                                notes,
                                status
                        )
                );

            } while (cursor.moveToNext());
        }

        cursor.close();

        eventAdapter = new EventAdapter(
                this,
                eventList,
                databaseHelper
        );

        recyclerEvents.setAdapter(eventAdapter);
    }
}