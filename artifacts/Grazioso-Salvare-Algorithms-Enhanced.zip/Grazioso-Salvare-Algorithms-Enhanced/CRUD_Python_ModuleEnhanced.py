from pymongo import MongoClient


class AnimalShelter:
    """CRUD operations for the Animal collection in MongoDB."""

    def __init__(self, username, password):
        # LOCAL MongoDB connection settings DB is related to local port on MongoDB Compass
        HOST = "localhost"
        PORT = 27017
        DB = "AAC"
        COL = "animals"

        # Connect to the local MongoDB database
        self.client = MongoClient(HOST, PORT)

        # Select the database and collection
        self.database = self.client[DB]
        self.collection = self.database[COL]

        # DATABASE ENHANCEMENT 1:
        # Add indexes for fields used by the new flexible search.
        self.collection.create_index("animal_type")
        self.collection.create_index("breed")
        self.collection.create_index("age_upon_outcome_in_weeks")
        self.collection.create_index("sex_upon_outcome")

    def create(self, data):
        """Insert one document into the animals collection."""

        if not isinstance(data, dict) or not data:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except Exception:
            return False

    def read(self, query):
        """Return documents that match the supplied query."""

        if not isinstance(query, dict):
            return []

        try:
            results = self.collection.find(query)
            return list(results)
        except Exception:
            return []

    # DATABASE ENHANCEMENT 2:
    # Build a MongoDB query using only the search options selected by the user.
    def build_search_query(
        self,
        animal_type=None,
        breed=None,
        min_age=None,
        max_age=None,
        sex=None
    ):
        query = {}

        # Add animal type only when one is selected.
        if animal_type:
            query["animal_type"] = animal_type

        # Add breed only when one is entered.
        if breed:
            query["breed"] = breed

        # Add sex only when one is selected.
        if sex:
            query["sex_upon_outcome"] = sex

        # Add an age range when a minimum or maximum age is entered.
        if min_age is not None or max_age is not None:
            age_query = {}

            if min_age is not None:
                age_query["$gte"] = min_age

            if max_age is not None:
                age_query["$lte"] = max_age

            query["age_upon_outcome_in_weeks"] = age_query

        return query

    # DATABASE ENHANCEMENT 3:
    # Search the collection using any combination of the optional fields.
    def search_animals(
        self,
        animal_type=None,
        breed=None,
        min_age=None,
        max_age=None,
        sex=None
    ):
        query = self.build_search_query(
            animal_type,
            breed,
            min_age,
            max_age,
            sex
        )

        return self.read(query)

    def update(self, query, new_values):
        """Update documents that match the supplied query."""

        if not isinstance(query, dict) or not isinstance(new_values, dict):
            return 0

        try:
            result = self.collection.update_many(
                query,
                {"$set": new_values}
            )
            return result.modified_count
        except Exception:
            return 0

    def delete(self, query):
        """Delete documents that match the supplied query."""

        if not isinstance(query, dict):
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception:
            return 0