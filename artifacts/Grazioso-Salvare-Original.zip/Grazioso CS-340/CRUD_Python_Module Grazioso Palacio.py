from pymongo import MongoClient


class AnimalShelter:
    """CRUD operations for the Animal collection in MongoDB."""

    def __init__(self, username, password):
        # this will serve as all needed connection info.
        USER = username
        PASS = password
        HOST = "localhost"
        PORT = 27017
        DB = "aac"
        COL = "animals"

        # this will make the connection to the DB.
        self.client = MongoClient(
            f"mongodb://{USER}:{PASS}@{HOST}:{PORT}/?authSource=admin"
        )

        # able to select and use the DB/CL.
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """Insert one document into the animals collection."""

        if not isinstance(data, dict) or not data:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except Exception:
            return False

    def read(self, query):
        """Return documents that match the supplied query."""

        if not isinstance(query, dict):
            return []

        try:
            results = self.collection.find(query)
            return list(results)
        except Exception:
            return []

    def update(self, query, new_values):
        """Update documents that match the supplied query."""

        if not isinstance(query, dict) or not isinstance(new_values, dict):
            return 0

        try:
            result = self.collection.update_many(
                query,
                {"$set": new_values}
            )
            return result.modified_count
        except Exception:
            return 0

    def delete(self, query):
        """Delete documents that match the supplied query."""

        if not isinstance(query, dict):
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception:
            return 0