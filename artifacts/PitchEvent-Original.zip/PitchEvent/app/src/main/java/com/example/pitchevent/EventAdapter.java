package com.example.pitchevent;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    Context context;
    ArrayList<Event> eventList;
    DatabaseHelper databaseHelper;

    public EventAdapter(Context context, ArrayList<Event> eventList, DatabaseHelper databaseHelper) {
        this.context = context;
        this.eventList = eventList;
        this.databaseHelper = databaseHelper;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = eventList.get(position);

        holder.textEventName.setText(event.getName());
        holder.textEventDateTime.setText(event.getDate());
        holder.textEventInfo.setText(event.getDescription());

        // Opens the add event screen in edit mode when the user taps the event.
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, AddEventsActivity.class);
            intent.putExtra("eventId", event.getId());
            intent.putExtra("eventName", event.getName());
            intent.putExtra("eventDate", event.getDate());
            intent.putExtra("eventDescription", event.getDescription());
            context.startActivity(intent);
        });

        // Removes an event from the database and updates the list.
        holder.buttonDeleteEvent.setOnClickListener(v -> {
            int currentPosition = holder.getBindingAdapterPosition();
            if (currentPosition != RecyclerView.NO_POSITION) {
                databaseHelper.deleteEvent(event.getId());
                eventList.remove(currentPosition);
                notifyItemRemoved(currentPosition);
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {

        TextView textEventName, textEventDateTime, textEventInfo;
        Button buttonDeleteEvent;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);

            textEventName = itemView.findViewById(R.id.textEventName);
            textEventDateTime = itemView.findViewById(R.id.textEventDateTime);
            textEventInfo = itemView.findViewById(R.id.textEventInfo);
            buttonDeleteEvent = itemView.findViewById(R.id.buttonDeleteEvent);
        }
    }
}