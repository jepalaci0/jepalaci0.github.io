package com.example.pitchevent;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    Button buttonAllowSms;
    Button buttonSkipSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        buttonAllowSms = findViewById(R.id.buttonAllowSms);
        buttonSkipSms = findViewById(R.id.buttonSkipSms);

        buttonAllowSms.setOnClickListener(v -> checkSmsPermission());

        buttonSkipSms.setOnClickListener(v -> {
            Toast.makeText(this, "SMS reminders skipped.", Toast.LENGTH_SHORT).show();
            openEventsScreen();
        });
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(this, "SMS reminders enabled.", Toast.LENGTH_SHORT).show();
            openEventsScreen();

        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(this, "SMS reminders enabled.", Toast.LENGTH_SHORT).show();

            } else {

                Toast.makeText(this, "SMS permission denied. App will still work.", Toast.LENGTH_SHORT).show();
            }

            openEventsScreen();
        }
    }

    private void openEventsScreen() {
        Intent intent = new Intent(SmsActivity.this, EventsActivity.class);
        startActivity(intent);
        finish();
    }
}