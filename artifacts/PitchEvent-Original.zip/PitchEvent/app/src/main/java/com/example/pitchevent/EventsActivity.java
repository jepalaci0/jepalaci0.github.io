package com.example.pitchevent;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class EventsActivity extends AppCompatActivity {

    RecyclerView recyclerEvents;
    Button buttonAddEvent;
    DatabaseHelper databaseHelper;
    ArrayList<Event> eventList;
    EventAdapter eventAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        recyclerEvents = findViewById(R.id.recyclerEvents);
        buttonAddEvent = findViewById(R.id.buttonAddEvent);

        databaseHelper = new DatabaseHelper(this);
        eventList = new ArrayList<>();

        recyclerEvents.setLayoutManager(new LinearLayoutManager(this));

        buttonAddEvent.setOnClickListener(v -> {
            Intent intent = new Intent(EventsActivity.this, AddEventsActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadEvents();
    }

    // Loads all events from the SQLite database into the RecyclerView.
    private void loadEvents() {
        eventList.clear();

        Cursor cursor = databaseHelper.getAllEvents();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                String date = cursor.getString(2);
                String description = cursor.getString(3);

                eventList.add(new Event(id, name, date, description));
            } while (cursor.moveToNext());
        }

        cursor.close();

        eventAdapter = new EventAdapter(this, eventList, databaseHelper);
        recyclerEvents.setAdapter(eventAdapter);
    }
}
