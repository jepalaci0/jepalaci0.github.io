package com.example.pitchevent;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddEventsActivity extends AppCompatActivity {

    EditText editEventName, editEventDate, editEventTime, editEventLocation, editEventNotes;
    Button buttonSaveEvent;
    DatabaseHelper databaseHelper;

    int eventId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        editEventName = findViewById(R.id.editEventName);
        editEventDate = findViewById(R.id.editEventDate);
        editEventTime = findViewById(R.id.editEventTime);
        editEventLocation = findViewById(R.id.editEventLocation);
        editEventNotes = findViewById(R.id.editEventNotes);
        buttonSaveEvent = findViewById(R.id.buttonSaveEvent);

        databaseHelper = new DatabaseHelper(this);

        // Checks if this screen was opened to edit an existing event.
        eventId = getIntent().getIntExtra("eventId", -1);

        if (eventId != -1) {
            editEventName.setText(getIntent().getStringExtra("eventName"));
            editEventDate.setText(getIntent().getStringExtra("eventDate"));
            editEventNotes.setText(getIntent().getStringExtra("eventDescription"));
            buttonSaveEvent.setText("Update Event");
        }

        buttonSaveEvent.setOnClickListener(v -> saveEvent());
    }

    private void saveEvent() {
        String name = editEventName.getText().toString().trim();
        String date = editEventDate.getText().toString().trim();
        String time = editEventTime.getText().toString().trim();
        String location = editEventLocation.getText().toString().trim();
        String notes = editEventNotes.getText().toString().trim();

        if (name.isEmpty() || date.isEmpty()) {
            Toast.makeText(this, "Please enter an event name and date.", Toast.LENGTH_SHORT).show();
            return;
        }

        String fullDate = date + " at " + time;
        String fullDescription = location + " - " + notes;

        boolean success;

        if (eventId == -1) {
            success = databaseHelper.addEvent(name, fullDate, fullDescription);
        } else {
            success = databaseHelper.updateEvent(eventId, name, fullDate, fullDescription);
        }

        if (success) {
            Toast.makeText(this, "Event saved.", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Event could not be saved.", Toast.LENGTH_SHORT).show();
        }
    }
}